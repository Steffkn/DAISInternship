﻿    namespace OBS.Models
{
    public class UserLoginInfo
    {
        public UserLoginInfo(int id, string name, string username, string passwordHash, string passwordSalt)
        {
            this.Id = id;
            this.Name = name;
            this.Username = username;
            this.PasswordHash = passwordHash;
            this.PasswordSalt = passwordSalt;
        }

        public int Id { get; private set; }

        public string Name { get; private set; }

        public string Username { get; private set; }

        public string PasswordHash { get; set; }

        public string PasswordSalt { get; set; }
    }
}
