﻿namespace OBS.Models
{
    public class PaymentComplition
    {
        public PaymentComplition(int id, int accountId, int userId, decimal amount)
        {
            this.Id = id;
            this.AccountId = accountId;
            this.UserId = userId;
            this.Amount = amount;
        }

        public int Id { get; set; }

        public int AccountId { get; set; }

        public int UserId { get; set; }

        public decimal Amount { get; set; }
    }
}
