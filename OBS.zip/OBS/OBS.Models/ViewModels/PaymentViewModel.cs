﻿namespace OBS.Models.ViewModels
{
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;

    public class PaymentViewModel
    {
        public ICollection<AccountInfo> Accounts { get; set; }

        [Display(Name = "Resieving account (IBAN)")]
        public string ResievingAccount { get; set; }

        public decimal Amount { get; set; }

        public string Reason { get; set; }
    }
}
