﻿namespace OBS.Models.BindingModels
{
    using System.ComponentModel.DataAnnotations;

    public class PaymentBindingModel
    {
        [Required(ErrorMessage = "Account is required.")]
        public int AccountId { get; set; }

        [Required(ErrorMessage = "Resieving account is required.")]
        [MinLength(22, ErrorMessage = "Resieving account should be exactly 22 symbols (ex. XX00XXXX00000000000000")]
        [MaxLength(22, ErrorMessage = "Resieving account should be exactly 22 symbols (ex. XX00XXXX00000000000000")]
        [RegularExpression("^[a-zA-Z0-9]*$", ErrorMessage = "Invalid IBAN. Only numbers and latin letters are allowed.")]
        public string ResievingAccount { get; set; }

        [Required(ErrorMessage = "Account field is required.")]
        public decimal Amount { get; set; }

        [Required(ErrorMessage = "Reason field is required.")]
        public string Reason { get; set; }
    }
}
