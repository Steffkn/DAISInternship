﻿namespace OBS.Models.BindingModels
{
    using System.ComponentModel.DataAnnotations;

    public class UserLoginBindingModel
    {
        [Required(ErrorMessage = "The username is required")]
        [MinLength(4, ErrorMessage = "The username must be at least {1} symbols long")]
        public string Username { get; set; }

        [Required(ErrorMessage = "The password is required")]
        [MinLength(4, ErrorMessage = "The password must be at least {1} symbols long")]
        public string Password { get; set; }
    }
}
