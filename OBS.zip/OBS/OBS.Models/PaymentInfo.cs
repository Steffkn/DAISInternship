﻿namespace OBS.Models
{
    using System;

    public class PaymentInfo
    {
        public PaymentInfo(int paymentId, string payerName, string iban, string holderName, string resieveingAccount, decimal balance, decimal amount, DateTime date, string status)
        {
            this.PaymentId = paymentId;
            this.PayerName = payerName;
            this.IBAN = iban;
            this.HolderName = holderName;
            this.ResieveingAccount = resieveingAccount;
            this.Balance = balance;
            this.Amount = amount;
            this.Date = date;
            this.Status = status;
        }

        public int PaymentId { get; private set; }

        public string PayerName { get; private set; }

        public string IBAN { get; private set; }

        public string HolderName { get; private set; }

        public string ResieveingAccount { get; private set; }

        public decimal Balance { get; private set; }

        public decimal Amount { get; private set; }

        public DateTime Date { get; private set; }

        public string Status { get; private set; }
    }
}
