﻿namespace OBS.Web.Filters
{
    using System.Web.Mvc;
    using System.Web.Routing;

    public class AuthorizeUserAttribute : AuthorizeAttribute
    {
        protected override void HandleUnauthorizedRequest(AuthorizationContext filterContext)
        {
            var loginRoute = new RouteValueDictionary(
                        new
                        {
                            controller = "Users",
                            action = "Login"
                        });
            filterContext.Result = new RedirectToRouteResult(loginRoute);
        }
    }
}