﻿namespace OBS.Web.Filters
{
    using System.Web.Mvc;
    using System.Web.Mvc.Filters;
    using OBS.Common;
    using OBS.Models;

    public class InitUserAttribute : ActionFilterAttribute, IAuthenticationFilter
    {
        public void OnAuthentication(AuthenticationContext filterContext)
        {
            var client = filterContext.HttpContext.Session[CommonConstants.SessionUserKey] as UserPrincipal;
            if (client != null)
            {
                filterContext.Principal = client;
            }
        }

        public void OnAuthenticationChallenge(AuthenticationChallengeContext filterContext)
        {
            // This is not needed, we can skip it
        }
    }
}