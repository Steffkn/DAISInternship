﻿namespace OBS.Web.Controllers
{
    using System.Web.Mvc;

    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return this.RedirectToAction("List", "Account");
        }
    }
}