﻿namespace OBS.Web.Controllers
{
    using System.Web.Mvc;
    using OBS.Common;
    using OBS.Models.BindingModels;
    using OBS.Services.Managers;
    using OBS.Web.Filters;

    public class UsersController : Controller
    {
        private UsersManager usersManager;

        public UsersController()
            : this(new UsersManager())
        {
        }

        public UsersController(UsersManager usersManager)
        {
            this.usersManager = usersManager;
        }

        [HttpGet]
        public ActionResult Login()
        {
            if (this.User.Identity.IsAuthenticated)
            {
                return this.RedirectToAction("Index", "Home");
            }

            return this.View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Login(UserLoginBindingModel userLoginInfo)
        {
            if (this.User.Identity.IsAuthenticated)
            {
                return this.RedirectToAction("Index", "Home");
            }

            if (ModelState.IsValid)
            {
                var userPrincipal = this.usersManager.LoginUser(userLoginInfo);

                if (userPrincipal != null)
                {
                    this.Session[CommonConstants.SessionUserKey] = userPrincipal;
                    return this.RedirectToAction("Index", "Home");
                }

                ModelState.AddModelError("LoginForm", "Invalid username or password!");
            }

            return this.View(userLoginInfo);
        }

        [AuthorizeUser]
        public ActionResult Logout()
        {
            this.Session[CommonConstants.SessionUserKey] = null;
            return this.RedirectToAction("Index", "Home");
        }
    }
}