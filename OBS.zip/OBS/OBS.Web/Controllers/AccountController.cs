﻿namespace OBS.Web.Controllers
{
    using System.Linq;
    using System.Web.Mvc;

    using OBS.Models.BindingModels;
    using OBS.Services.Extensions;
    using OBS.Services.Managers;
    using OBS.Web.Filters;

    [AuthorizeUser]
    public class AccountController : Controller
    {
        private AccountsManager accountsManager;

        public AccountController()
            : this(new AccountsManager())
        {
        }

        public AccountController(AccountsManager accountsManager)
        {
            this.accountsManager = accountsManager;
        }

        public ActionResult List()
        {
            var accoutns = this.accountsManager.GetAccountsByUsername(this.User.Identity.Name);
            return this.View(accoutns);
        }

        public ActionResult Payments()
        {
            var paiments = this.accountsManager.GetPaimentsByUsername(this.User.Identity.Name);
            return this.View(paiments);
        }

        [HttpGet]
        public ActionResult Payment()
        {
            var accounts = this.accountsManager.GetAccountsByUsername(this.User.Identity.Name)
                .Select(acc => new { Id = acc.Id, Name = $"{acc.IBAN} - {acc.Balance}" });
            ViewBag.Accounts = new SelectList(accounts, "Id", "Name", "-- none --");
            return this.View();
        }

        [HttpPost]
        public ActionResult Payment(PaymentBindingModel payment)
        {
            if (ModelState.IsValid)
            {
                var userId = this.User.GetUserId();
                bool success = this.accountsManager.CreatePayment(payment, userId);
                if (success)
                {
                    return this.RedirectToAction("Payments");
                }
            }

            this.TempData["PaymentError"] = "The payment counld not be created!";
            return this.RedirectToAction("Payment");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Complete(int id)
        {
            var userId = this.User.GetUserId();
            bool success = this.accountsManager.CompletePayment(id, userId);
            if (!success)
            {
                ViewBag.PaymentError = "The payment counld not be completed!";
            }

            return this.RedirectToAction("Payments");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Cancel(int id)
        {
            var userId = this.User.GetUserId();
            bool success = this.accountsManager.CancelPayment(id, userId);
            if (!success)
            {
                ViewBag.PaymentError = "The payment counld not be canceled!";
            }

            return this.RedirectToAction("Payments");
        }
    }
}