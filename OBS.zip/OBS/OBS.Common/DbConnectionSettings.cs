﻿namespace OBS.Common
{
   public static class DbConnectionSettings
    {
        public const string ConnectionString = "Data Source=.;Integrated Security=True;Database=OnlineBankingSystem";
    }
}
