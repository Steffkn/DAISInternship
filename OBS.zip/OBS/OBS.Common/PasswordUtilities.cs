﻿namespace OBS.Common
{
    using System.Linq;
    using System.Security.Cryptography;
    using System.Text;

    public static class PasswordUtilities
    {
        private const int DefaultSaltLenght = 64;
        private const string SaltCharacters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        private static RandomNumberGenerator random;
        private static SHA256 hashingAlgorithm;

        static PasswordUtilities()
        {
            // RNGCryptoServiceProvider is more secure than just Random class (its harder to predict)
            random = new RNGCryptoServiceProvider();
            hashingAlgorithm = new SHA256Managed();
        }

        public static string GeneratePasswordHash(string password, string salt)
        {
            var passwordHashBytes = hashingAlgorithm.ComputeHash(Encoding.UTF8.GetBytes(password + salt));
            var passwordHash = string.Join(string.Empty, passwordHashBytes.Select(b => b.ToString("x2")));
            return passwordHash;
        }
    }
}
