﻿namespace OBS.Common
{
    public static class CommonConstants
    {
        public const string SessionUserKey = "user";
    }
}
