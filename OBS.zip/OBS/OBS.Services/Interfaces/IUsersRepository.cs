﻿namespace OBS.Services.Interfaces
{
    using OBS.Models;

    public interface IUsersRepository
    {
        UserLoginInfo GetUserByUsername(string username);
    }
}
