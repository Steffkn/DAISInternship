﻿namespace OBS.Services.Interfaces
{
    using System.Collections.Generic;
    using OBS.Models;

    public interface IAccountsRepository
    {
        ICollection<AccountInfo> GetAccountsForUsername(string username);

        ICollection<PaymentInfo> GetPaymentsForUsername(string username);

        bool ChechIfUserHasAmount(int accountId, decimal amount);

        bool CreatePayment(int accountId, int userId, string resievingAccount, decimal amount, string reason);

        PaymentComplition GetPayment(int id);

        bool SetAvailableAmoutForAccount(int accountId, decimal amount);

        bool ChangePaymentStatus(int id, int statusId);

        decimal GetAccountAvailableAmount(int accountId);
    }
}
