﻿namespace OBS.Services.Repositories
{
    using System;
    using System.Collections.Generic;

    using OBS.Models;
    using OBS.Services.Interfaces;

    public class AccountsRepository : DbRepository, IAccountsRepository
    {
        public AccountsRepository()
        {
        }

        public AccountsRepository(string connectionString)
            : base(connectionString)
        {
        }

        public bool ChechIfUserHasAmount(int accountId, decimal amount)
        {
            string query =
                @"SELECT AvailableAmount
                FROM Accounts
                WHERE Id = @accountId";
            var parameters = new Dictionary<string, object>
            {
                {
                    "@accountId", accountId
                }
            };

            decimal result = (decimal)this.ExecuteScalar(query, parameters);
            return result >= amount;
        }

        public bool CreatePayment(int accountId, int userId, string resievingAccount, decimal amount, string reason)
        {
            string query =
                @"INSERT INTO Paiments VALUES
                (@accountID, @userId, @resievingAccount, @amount, @reasoning, @paimentStatus, @date);";
            var parameters = new Dictionary<string, object>
            {
                {
                    "@accountID", accountId
                },
                {
                    "@userId", userId
                },
                {
                    "@resievingAccount", resievingAccount
                },
                {
                    "@amount", amount
                },
                {
                    "@reasoning", reason
                },
                {
                    "@paimentStatus", 1
                },
                {
                    "@date", DateTime.Now
                } // DateTime.UtcNow
            };

            int reader = this.ExecuteNonQuery(query, parameters);

            return reader != -1;
        }

        public ICollection<AccountInfo> GetAccountsForUsername(string username)
        {
            string query =
                @"SELECT ac.Id, ac.IBAN, ac.AvailableAmount, u.Name as HolderName FROM UsersAccounts
                JOIN Accounts as ac
                ON ac.Id = AccountId
                JOIN Users as u
                ON u.Id = ac.HolderId
                WHERE UserId = (SELECT Id FROM Users WHERE Username = @username)";
            var parameters = new Dictionary<string, object>
            {
                {
                    "@username", username
                }
            };

            var accounts = new List<AccountInfo>();

            var reader = this.ExecuteReader(query, parameters);

            while (reader.Read())
            {
                int id = reader.GetInt32(0);
                string iban = reader.GetString(1);
                decimal balance = reader.GetDecimal(2);
                string holderName = reader.GetString(3);

                accounts.Add(new AccountInfo(id, iban, balance, holderName));
            }

            return accounts;
        }

        public ICollection<PaymentInfo> GetPaymentsForUsername(string username)
        {
            string query =
                  @"SELECT
                        p.Id,
                        u.Name as PayerName, 
                        a.IBAN, 
                        h.Name as HolderName, 
                        p.ReceivingAccount,  
                        a.AvailableAmount as Balance, 
                        p.Amount, 
                        p.Date, 
                        ps.Name 
                    FROM Paiments as p
                    JOIN PaimentStatus as ps
                    ON p.PaimentStatusId = ps.Id
                    JOIN Accounts as a
                    ON a.Id = p.AccountId
                    JOIN Users as u
                    ON u.Id = p.UserId
                    JOIN Users as h
                    ON h.Id = a.HolderId
                    WHERE u.Username = @username
                    ORDER BY ps.Id ASC";
            var parameters = new Dictionary<string, object>
            {
                { "@username", username }
            };

            var paiments = new List<PaymentInfo>();

            using (var reader = this.ExecuteReader(query, parameters))
            {
                while (reader.Read())
                {
                    int paymentId = reader.GetInt32(0);
                    string payerName = reader.GetString(1);
                    string iban = reader.GetString(2);
                    string holderName = reader.GetString(3);
                    string resieveingAccount = reader.GetString(4);
                    decimal balance = reader.GetDecimal(5);
                    decimal amount = reader.GetDecimal(6);
                    DateTime date = reader.GetDateTime(7);
                    string status = reader.GetString(8);

                    paiments.Add(new PaymentInfo(paymentId, payerName, iban, holderName, resieveingAccount, balance, amount, date, status));
                }
            }

            return paiments;
        }

        public PaymentComplition GetPayment(int id)
        {
            string query =
                @"SELECT AccountId, UserId, Amount FROM Paiments
                WHERE Id = @id;";
            var parameters = new Dictionary<string, object>
            {
                { "@id", id }
            };

            PaymentComplition paymentComplition = null;
            using (var reader = this.ExecuteReader(query, parameters))
            {
                while (reader.Read())
                {
                    int accountId = reader.GetInt32(0);
                    int userId = reader.GetInt32(1);
                    decimal amount = reader.GetDecimal(2);

                    paymentComplition = new PaymentComplition(id, accountId, userId, amount);
                }
            }

            return paymentComplition;
        }

        public bool SetAvailableAmoutForAccount(int accountId, decimal ammount)
        {
            string query =
                @"UPDATE Accounts
                SET AvailableAmount = @amount
                WHERE Id = @accountId";
            var parameters = new Dictionary<string, object>
            {
                { "@accountId", accountId },
                { "@amount", ammount }
            };

            int result = this.ExecuteNonQuery(query, parameters);

            return result != -1;
        }

        public bool ChangePaymentStatus(int id, int statusId)
        {
            string query =
                @"UPDATE Paiments
                SET PaimentStatusId = @statusId
                WHERE Id = @Id";
            var parameters = new Dictionary<string, object>
            {
                { "@statusId", statusId },
                { "@id", id }
            };

            int result = this.ExecuteNonQuery(query, parameters);

            return result != -1;
        }

        public decimal GetAccountAvailableAmount(int accountId)
        {
            string query =
                @"SELECT AvailableAmount FROM Accounts
                WHERE Id = @Id";
            var parameters = new Dictionary<string, object>
            {
                { "@id", accountId }
            };

            decimal result = (decimal)this.ExecuteScalar(query, parameters);
            return result;
        }
    }
}
