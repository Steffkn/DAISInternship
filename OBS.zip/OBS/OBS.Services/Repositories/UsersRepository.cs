﻿namespace OBS.Services.Repositories
{
    using System.Collections.Generic;

    using OBS.Models;
    using OBS.Services.Interfaces;

    public class UsersRepository : DbRepository, IUsersRepository
    {
        public UsersRepository()
        {
        }

        public UsersRepository(string connectionString)
            : base(connectionString)
        {
        }

        public UserLoginInfo GetUserByUsername(string username)
        {
            string query =
                @"SELECT
                    Id,
                    Name,
                    Username,
                    PasswordHash,
                    PasswordSalt
                FROM Users
                WHERE Username = @username";
            var parameters = new Dictionary<string, object>
            {
                { "@username", username }
            };

            var reader = this.ExecuteReader(query, parameters);

            UserLoginInfo client = null;
            using (reader)
            {
                for (int usersCount = 0; reader.Read() && usersCount <= 1; usersCount++)
                {
                    int id = reader.GetInt32(0);
                    string name = reader.GetString(1);
                    string usernameFromDatabase = reader.GetString(2);
                    string passwordHash = reader.GetString(3);
                    string passwordSalt = reader.GetString(4);
                    client = new UserLoginInfo(id, name, usernameFromDatabase, passwordHash, passwordSalt);
                }
            }

            return client;
        }
    }
}
