﻿namespace OBS.Services.Extensions
{
    using System.Security.Principal;
    using OBS.Models;

    public static class UserExtensions
    {
        public static int GetUserId(this IPrincipal principal)
        {
            var user = principal as UserPrincipal;
            if (user != null)
            {
                return user.Id;
            }

            return 0;
        }
    }
}
