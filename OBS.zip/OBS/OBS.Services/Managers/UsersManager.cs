﻿namespace OBS.Services.Managers
{
    using OBS.Common;
    using OBS.Models;
    using OBS.Models.BindingModels;
    using OBS.Services.Interfaces;
    using OBS.Services.Repositories;

    public class UsersManager
    {
        private IUsersRepository userRepository;

        public UsersManager()
            : this(new UsersRepository())
        {
        }

        public UsersManager(IUsersRepository userRepository)
        {
            this.userRepository = userRepository;
        }

        public UserPrincipal LoginUser(UserLoginBindingModel userLoginInfo)
        {
            var userInfo = this.userRepository.GetUserByUsername(userLoginInfo.Username);
            UserPrincipal userPrincipal = null;

            if (userInfo != null)
            {
                var passwordHash = PasswordUtilities.GeneratePasswordHash(userLoginInfo.Password, userInfo.PasswordSalt);
                if (passwordHash == userInfo.PasswordHash)
                {
                    userPrincipal = new UserPrincipal(userInfo.Id, userInfo.Username);
                }
            }

            return userPrincipal;
        }
    }
}
