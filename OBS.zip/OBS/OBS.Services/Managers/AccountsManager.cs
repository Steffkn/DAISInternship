﻿namespace OBS.Services.Managers
{
    using System.Collections.Generic;

    using OBS.Models;
    using OBS.Models.BindingModels;
    using OBS.Services.Interfaces;
    using OBS.Services.Repositories;

    public class AccountsManager
    {
        private IAccountsRepository accountsRepository;

        public AccountsManager()
            : this(new AccountsRepository())
        {
        }

        public AccountsManager(IAccountsRepository accountsRepository)
        {
            this.accountsRepository = accountsRepository;
        }

        public ICollection<AccountInfo> GetAccountsByUsername(string username)
        {
            return this.accountsRepository.GetAccountsForUsername(username);
        }

        public ICollection<PaymentInfo> GetPaimentsByUsername(string username)
        {
            return this.accountsRepository.GetPaymentsForUsername(username);
        }

        public bool CreatePayment(PaymentBindingModel username, int userId)
        {
            bool hasAmount = this.accountsRepository.ChechIfUserHasAmount(username.AccountId, username.Amount);
            if (!hasAmount)
            {
                return false;
            }

            bool paimentCreated = this.accountsRepository.CreatePayment(username.AccountId, userId, username.ResievingAccount, username.Amount, username.Reason);

            return paimentCreated;
        }

        public bool CompletePayment(int id, int userId)
        {
            var payment = this.accountsRepository.GetPayment(id);

            bool hasAmount = this.accountsRepository.ChechIfUserHasAmount(payment.AccountId, payment.Amount);
            if (!hasAmount)
            {
                return false;
            }

            decimal oldAmount = this.accountsRepository.GetAccountAvailableAmount(payment.AccountId);
            decimal newAmount = oldAmount - payment.Amount;
            bool paimentCompleted = this.accountsRepository.SetAvailableAmoutForAccount(payment.AccountId, newAmount);
            this.accountsRepository.ChangePaymentStatus(id, 2);
            return paimentCompleted;
        }

        public bool CancelPayment(int id, int userId)
        {
            return this.accountsRepository.ChangePaymentStatus(id, 3);
        }
    }
}
