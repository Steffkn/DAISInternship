﻿using LocalPub.Domain.Interfaces;
using LocalPub.Models;
using LocalPub.Utilities;
using System;
using System.Collections.Generic;

namespace LocalPub.Domain.SqlServer
{
    public class SqlMenuRepository : DbRepository, IMenuRepository
    {
        public SqlMenuRepository()
        {
        }

        public SqlMenuRepository(string connectionString)
            : base(connectionString)
        {
        }

        public MenuViewModel GetMenu()
        {
            var reader = this.ExecuteReader(
                    @"select
	                    mt.Name as MealType,
	                    m.Id as MealId,
	                    m.Name as MealName
                    from Meals as m
                    join MealTypes as mt
                    on m.MealTypeId = mt.Id");

            var appetizers = new List<MealDescription>();
            var mainCourses = new List<MealDescription>();
            var desserts = new List<MealDescription>();
            using (reader)
            {
                while (reader.Read())
                {
                    string mealTypeName = reader.GetString(0);
                    int mealId = reader.GetInt32(1);
                    string mealName = reader.GetString(2);
                    var meal = new MealDescription(mealId, mealName);
                    switch (mealTypeName)
                    {
                        case "Предястие":
                            appetizers.Add(meal);
                            break;
                        case "Основно ястие":
                            mainCourses.Add(meal);
                            break;
                        case "Десерт":
                            desserts.Add(meal);
                            break;
                        default:
                            throw new InvalidOperationException("No such meal type: " + mealTypeName);
                    }
                }
            }

            MenuViewModel menu = new MenuViewModel(appetizers, mainCourses, desserts);
            return menu;
        }
    }
}
