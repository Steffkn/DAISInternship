﻿using LocalPub.Domain.Interfaces;
using LocalPub.Models;
using System;
using System.Collections.Generic;

namespace LocalPub.Domain.SqlServer
{
    public class SqlOrdersRepository : DbRepository, IOrdersRepository
    {
        public SqlOrdersRepository()
        {
        }

        public SqlOrdersRepository(string connectionString)
            : base(connectionString)
        {
        }

        public int GetNumberOfOrdersForClient(int clientId, DateTime date)
        {
            int count = (int)this.ExecuteScalar(
                    @"select count(*) as OrdersCount
                    from Orders
                    where OrderDate = @date
                    and ClientId = @clientId
                    and Orders.IsCancelled = 0",
                    new Dictionary<string, object>()
                    {
                        {"@date", date },
                        {"@clientId", clientId }
                    });
            return count;
        }

        public bool SaveOrder(OrderWithMeals order)
        {
            int orderId = (int)this.ExecuteScalar(
                @"insert into Orders
                    (ClientId, OrderDate, IsCancelled)
                output INSERTED.ID
                values (@clientId, @date, 0)",
                new Dictionary<string, object>()
                    {
                        {"@date", order.Today },
                        {"@clientId", order.ClientId }
                });

            if (orderId <= 0)
            {
                return false;
            }

            // TODO: Refactor these
            if (order.AppetizerId.HasValue)
            {
                this.ExecuteNonQuery(
                    @"insert into OrderMeals (OrderId, MealId)
                    values (@orderId, @mealId)",
                    new Dictionary<string, object>()
                    {
                        {"@orderId", orderId },
                        {"@mealId", order.AppetizerId.Value }
                    });
            }

            if (order.MainCourseId.HasValue)
            {
                this.ExecuteNonQuery(
                    @"insert into OrderMeals (OrderId, MealId)
                    values (@orderId, @mealId)",
                    new Dictionary<string, object>()
                    {
                        {"@orderId", orderId },
                        {"@mealId", order.MainCourseId.Value }
                    });
            }

            if (order.DessertId.HasValue)
            {
                this.ExecuteNonQuery(
                    @"insert into OrderMeals (OrderId, MealId)
                    values (@orderId, @mealId)",
                    new Dictionary<string, object>()
                    {
                        {"@orderId", orderId },
                        {"@mealId", order.DessertId.Value }
                    });
            }

            return true;
        }
    }
}
