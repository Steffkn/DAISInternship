﻿using LocalPub.Models;
using System;

namespace LocalPub.Domain.Interfaces
{
    public interface IOrdersRepository : IDbRepository
    {
        int GetNumberOfOrdersForClient(int clientId, DateTime date);

        bool SaveOrder(OrderWithMeals order);
    }
}
