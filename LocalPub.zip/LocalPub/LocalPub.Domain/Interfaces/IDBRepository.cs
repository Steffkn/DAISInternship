﻿using System;

namespace LocalPub.Domain.Interfaces
{
    public interface IDbRepository : IDisposable
    {
    }
}
