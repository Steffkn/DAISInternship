﻿using LocalPub.Models;

namespace LocalPub.Domain.Interfaces
{
    public interface IMenuRepository : IDbRepository
    {
        MenuViewModel GetMenu();
    }
}
