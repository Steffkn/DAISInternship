﻿using LocalPub.Domain.Interfaces;
using LocalPub.Domain.SqlServer;
using LocalPub.Models;
using LocalPub.Models.BindingModels;
using System;

namespace LocalPub.Domain.Managers
{
    public class OrderManager
    {
        private IMenuRepository menuRepository;
        private IOrdersRepository ordersRepository;

        public OrderManager()
            : this(new SqlMenuRepository(), new SqlOrdersRepository())
        {
        }

        public OrderManager(IMenuRepository menuRepository, IOrdersRepository ordersRepository)
        {
            this.menuRepository = menuRepository;
            this.ordersRepository = ordersRepository;
        }

        public MenuViewModel PrepareOrderMenu()
        {
            return this.menuRepository.GetMenu();
        }

        public bool SaveOrder(OrderWithMeals order)
        {
            int currentOrdersCount = this.ordersRepository.GetNumberOfOrdersForClient(order.ClientId, order.Today);
            if (currentOrdersCount != 0)
            {
                // We can't have multiple active orders for a given day
                return false;
            }

            return this.ordersRepository.SaveOrder(order);
        }
    }
}
