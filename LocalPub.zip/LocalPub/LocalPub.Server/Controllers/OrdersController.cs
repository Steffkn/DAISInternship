﻿using LocalPub.Domain.Managers;
using LocalPub.Models;
using LocalPub.Models.BindingModels;
using System;
using System.Web.Mvc;

namespace LocalPub.Server.Controllers
{
    public class OrdersController : Controller
    {
        private OrderManager orderManager;

        public OrdersController()
            : this(new OrderManager())
        {
        }

        public OrdersController(OrderManager clientManager)
        {
            this.orderManager = clientManager;
        }

        [HttpGet]
        public ActionResult MakeOrder()
        {
            var menu = this.orderManager.PrepareOrderMenu();
            ViewBag.AppetizersList = new SelectList(menu.Appetizers, "Id", "Name", "-- none --");
            ViewBag.MainCoursesList = new SelectList(menu.MainCourses, "Id", "Name", "-- none --");
            ViewBag.DessertsList = new SelectList(menu.Desserts, "Id", "Name", "-- none --");

            var orderModel = new OrderBindingModel();
            return this.View(orderModel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult MakeOrder(OrderBindingModel order)
        {
            // TODO: ModelState at the beginning?
            var orderToSave = new OrderWithMeals()
            {
                AppetizerId = order.AppetizerId,
                MainCourseId = order.MainCourseId,
                DessertId = order.DessertId,
                ClientId = this.User.GetUserId(),
                Today = DateTime.Today
            };
            bool saveSuccess = this.orderManager.SaveOrder(orderToSave);
            if (!saveSuccess)
            {
                this.ModelState.AddModelError("Form", "The order was not saved correctly.");
                return this.View();
            }

            // TODO: view my orders and allow for order cancellation
            return this.RedirectToAction("MakeOrder", "Orders");
        }
    }
}