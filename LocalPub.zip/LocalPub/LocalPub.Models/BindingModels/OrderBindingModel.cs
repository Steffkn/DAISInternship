﻿using System;

namespace LocalPub.Models.BindingModels
{
    public class OrderBindingModel
    {
        public int? AppetizerId { get; set; }

        public int? MainCourseId { get; set; }

        public int? DessertId { get; set; }

        // TODO: 2 desserts for връзкарs
    }
}
