﻿using LocalPub.Models.BindingModels;
using System;

namespace LocalPub.Models
{
    public class OrderWithMeals : OrderBindingModel
    {
        public int ClientId { get; set; }

        public DateTime Today { get; set; }
    }
}
