﻿namespace LocalPub.Utilities
{
    public static class SqlServerConstants
    {
        public const string ConnectionString = "Data Source=.;Integrated Security=True;Database=LocalPub";
    }
}
